document.querySelector('.star').addEventListener('click', () => {
    const star = document.createElement('div');
    star.classList.add('star');
    star.style.left = `${Math.random() * window.innerWidth}px`;
    star.style.top = `${Math.random() * window.innerHeight}px`;
    document.body.appendChild(star);

    const paskoNa = document.createElement('div');
    paskoNa.classList.add('pasko-na');
    paskoNa.style.left = `${Math.random() * window.innerWidth}px`;
    paskoNa.style.top = `${Math.random() * window.innerHeight}px`;
    document.body.appendChild(paskoNa);

    setInterval(() => {
        const trail = document.createElement('div');
        trail.classList.add('trail');
        trail.style.left = `${parseFloat(paskoNa.style.left) + 25}px`;
        trail.style.top = `${parseFloat(paskoNa.style.top) + 25}px`;
        document.body.appendChild(trail);
    }, 200);
});


