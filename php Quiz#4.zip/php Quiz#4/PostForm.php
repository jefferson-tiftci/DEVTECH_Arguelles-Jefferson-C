<!DOCTYPE html>
<html>
<head>
    <title>PostForm.php</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .form-container {
            border: 1px solid #ccc;
            padding: 20px;
            width: 300px;
            margin: 20px auto;
            background-color: blue;
        }
        .form-container h2 {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin: -20px -20px 10px;
        }
        .form-container label {
            display: block;
            margin: 10px 0 5px;
        }
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        .form-container .radio-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .form-container input[type="radio"] {
            width: auto;
            margin: 0 5px 0 0;
        }
        .form-container .submit-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>PostForm.php</h2>
        <form action="postform_submitted.php" method="post">
            <label for="name">My name is:</label>
            <input type="text" id="name" name="name" required>

            <label for="movie">My favourite movie is:</label>
            <input type="text" id="movie" name="movie" required>

            <label for="degree">My degree is:</label>
            <select id="degree" name="degree">
                <option value="Bachelor">Bachelor</option>
                <option value="Master">Master</option>
            </select>

            <label>Gender:</label>
            <div class="radio-group">
                <input type="radio" id="male" name="gender" value="Male" required>
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="Female">
                <label for="female">Female</label>
            </div>

            <label for="subjects">My favourite unit(s) *multiselect:</label>
            <select id="subjects" name="subjects[]" multiple>
                <option value="Math">Math</option>
                <option value="English">Englis</option>
                <option value="Science">Chemistry</option>
                <option value="AP">Biology</option>
            </select>

            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>
</body>
</html>
