<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $movie = htmlspecialchars($_POST['movie']);
    $degree = htmlspecialchars($_POST['degree']);
    $gender = htmlspecialchars($_POST['gender']);
    $subjects = isset($_POST['subjects']) ? $_POST['subjects'] : [];

    echo "<h1>Hello $name</h1>";
    echo "<p>You like movie \"$movie\"</p>";
    echo "<p>You are enrolled in $degree's Degree.</p>";
    echo "<p>Your gender is $gender.</p>";
    if (!empty($subjects)) {
        echo "<p>Your favorite subject(s) is/are: " . implode(", ", $subjects) . ".</p>";
    } else {
        echo "<p>You didn't select any favorite subjects.</p>";
    }
} else {
    echo "<p>No form data submitted.</p>";
}
?>
